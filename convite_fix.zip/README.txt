Suba todos estes arquivos para a RAIZ do seu repositório.
- Se o fundo não aparecer, confirme que a pasta img/ e os arquivos estão na raiz e respeitam maiúsculas/minúsculas.
- A trilha já aponta para audio/trilha.mp3.
